create function arraycontained(anyarray, anyarray) returns boolean
    language internal
as
$$ arraycontained $$;

comment on function arraycontained(anyarray, anyarray) is 'implementation of <@ operator';

