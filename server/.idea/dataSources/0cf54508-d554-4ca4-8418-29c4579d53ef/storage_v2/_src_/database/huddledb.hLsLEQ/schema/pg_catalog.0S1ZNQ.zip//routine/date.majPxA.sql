create function date(timestamp without time zone) returns date
    language internal
as
$$ timestamp_date $$;

comment on function date(timestamptz) is 'convert timestamp with time zone to date';

