create function box(point, point) returns box
    language internal
as
$$ points_box $$;

comment on function box(point) is 'convert point to empty box';

