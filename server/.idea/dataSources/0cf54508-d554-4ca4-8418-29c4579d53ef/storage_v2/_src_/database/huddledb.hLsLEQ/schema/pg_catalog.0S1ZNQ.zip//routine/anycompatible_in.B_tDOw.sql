create function anycompatible_in(cstring) returns anycompatible
    language internal
as
$$ anycompatible_in $$;

comment on function anycompatible_in(cstring) is 'I/O';

