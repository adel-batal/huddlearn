create function boolin(cstring) returns boolean
    language internal
as
$$ boolin $$;

comment on function boolin(cstring) is 'I/O';

