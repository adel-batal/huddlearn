create function _pg_truetypmod(pg_attribute, pg_type) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

