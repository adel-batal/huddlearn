create function box_contained(box, box) returns boolean
    language internal
as
$$ box_contained $$;

comment on function box_contained(box, box) is 'implementation of <@ operator';

