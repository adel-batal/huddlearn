create function binary_upgrade_set_next_toast_relfilenode(oid) returns void
    language internal
as
$$ binary_upgrade_set_next_toast_relfilenode $$;

comment on function binary_upgrade_set_next_toast_relfilenode(oid) is 'for use by pg_upgrade';

