create function box_overleft(box, box) returns boolean
    language internal
as
$$ box_overleft $$;

comment on function box_overleft(box, box) is 'implementation of &< operator';

