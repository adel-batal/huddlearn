create function cbrt(double precision) returns double precision
    language internal
as
$$ dcbrt $$;

comment on function cbrt(float8) is 'cube root';

