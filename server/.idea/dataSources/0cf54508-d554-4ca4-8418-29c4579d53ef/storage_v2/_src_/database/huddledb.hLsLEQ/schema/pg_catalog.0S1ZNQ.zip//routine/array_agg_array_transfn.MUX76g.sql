create function array_agg_array_transfn(internal, anyarray) returns internal
    language internal
as
$$ array_agg_array_transfn $$;

comment on function array_agg_array_transfn(internal, anyarray) is 'aggregate transition function';

