create function chr(integer) returns text
    language internal
as
$$ chr $$;

comment on function chr(int4) is 'convert int4 to char';

