create function area(box) returns double precision
    language internal
as
$$ box_area $$;

comment on function area(path) is 'area of a closed path';

