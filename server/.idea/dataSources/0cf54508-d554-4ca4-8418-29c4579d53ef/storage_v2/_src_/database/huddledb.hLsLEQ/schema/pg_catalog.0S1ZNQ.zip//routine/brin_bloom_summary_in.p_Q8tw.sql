create function brin_bloom_summary_in(cstring) returns pg_brin_bloom_summary
    language internal
as
$$ brin_bloom_summary_in $$;

comment on function brin_bloom_summary_in(cstring) is 'I/O';

