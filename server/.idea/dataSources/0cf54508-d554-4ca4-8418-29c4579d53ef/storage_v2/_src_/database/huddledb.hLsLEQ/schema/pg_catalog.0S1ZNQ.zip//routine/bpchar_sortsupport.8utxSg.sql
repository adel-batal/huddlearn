create function bpchar_sortsupport(internal) returns void
    language internal
as
$$ bpchar_sortsupport $$;

comment on function bpchar_sortsupport(internal) is 'sort support';

