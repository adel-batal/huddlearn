create function box_ge(box, box) returns boolean
    language internal
as
$$ box_ge $$;

comment on function box_ge(box, box) is 'implementation of >= operator';

