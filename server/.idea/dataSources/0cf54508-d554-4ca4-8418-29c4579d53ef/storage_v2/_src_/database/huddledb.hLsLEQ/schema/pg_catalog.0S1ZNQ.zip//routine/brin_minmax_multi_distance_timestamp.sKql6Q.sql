create function brin_minmax_multi_distance_timestamp(internal, internal) returns double precision
    language internal
as
$$ brin_minmax_multi_distance_timestamp $$;

comment on function brin_minmax_multi_distance_timestamp(internal, internal) is 'BRIN multi minmax timestamp distance';

