create function brin_inclusion_opcinfo(internal) returns internal
    language internal
as
$$ brin_inclusion_opcinfo $$;

comment on function brin_inclusion_opcinfo(internal) is 'BRIN inclusion support';

