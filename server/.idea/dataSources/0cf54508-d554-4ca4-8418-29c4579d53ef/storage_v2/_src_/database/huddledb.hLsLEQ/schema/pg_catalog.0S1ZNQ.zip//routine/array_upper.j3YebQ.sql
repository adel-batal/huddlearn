create function array_upper(anyarray, integer) returns integer
    language internal
as
$$ array_upper $$;

comment on function array_upper(anyarray, int4) is 'array upper dimension';

