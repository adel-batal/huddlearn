create function binary_upgrade_set_missing_value(oid, text, text) returns void
    language internal
as
$$ binary_upgrade_set_missing_value $$;

comment on function binary_upgrade_set_missing_value(oid, text, text) is 'for use by pg_upgrade';

