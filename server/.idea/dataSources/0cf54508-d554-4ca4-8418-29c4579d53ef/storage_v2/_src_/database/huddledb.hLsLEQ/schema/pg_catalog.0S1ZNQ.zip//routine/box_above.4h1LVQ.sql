create function box_above(box, box) returns boolean
    language internal
as
$$ box_above $$;

comment on function box_above(box, box) is 'implementation of |>> operator';

