create function anymultirange_in(cstring, oid, integer) returns anymultirange
    language internal
as
$$ anymultirange_in $$;

comment on function anymultirange_in(cstring, oid, int4) is 'I/O';

