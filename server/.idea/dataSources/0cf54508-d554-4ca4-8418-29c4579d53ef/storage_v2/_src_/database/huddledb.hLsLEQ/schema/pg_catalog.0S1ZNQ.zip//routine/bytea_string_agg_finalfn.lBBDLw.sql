create function bytea_string_agg_finalfn(internal) returns bytea
    language internal
as
$$ bytea_string_agg_finalfn $$;

comment on function bytea_string_agg_finalfn(internal) is 'aggregate final function';

