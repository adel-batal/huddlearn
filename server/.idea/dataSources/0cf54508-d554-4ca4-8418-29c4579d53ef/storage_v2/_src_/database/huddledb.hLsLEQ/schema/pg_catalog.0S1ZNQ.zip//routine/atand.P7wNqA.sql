create function atand(double precision) returns double precision
    language internal
as
$$ datand $$;

comment on function atand(float8) is 'arctangent, degrees';

