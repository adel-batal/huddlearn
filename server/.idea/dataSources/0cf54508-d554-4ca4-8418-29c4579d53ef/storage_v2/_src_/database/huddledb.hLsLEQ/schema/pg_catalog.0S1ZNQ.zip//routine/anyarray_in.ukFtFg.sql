create function anyarray_in(cstring) returns anyarray
    language internal
as
$$ anyarray_in $$;

comment on function anyarray_in(cstring) is 'I/O';

