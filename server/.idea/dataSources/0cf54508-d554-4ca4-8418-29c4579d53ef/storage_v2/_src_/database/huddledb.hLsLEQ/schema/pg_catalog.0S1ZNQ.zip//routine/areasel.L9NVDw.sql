create function areasel(internal, oid, internal, integer) returns double precision
    language internal
as
$$ areasel $$;

comment on function areasel(internal, oid, internal, int4) is 'restriction selectivity for area-comparison operators';

