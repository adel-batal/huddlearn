create function age(xid) returns integer
    language internal
as
$$ xid_age $$;

comment on function age(timestamp, timestamp) is 'date difference preserving months and years';

