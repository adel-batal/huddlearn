create function brin_minmax_multi_opcinfo(internal) returns internal
    language internal
as
$$ brin_minmax_multi_opcinfo $$;

comment on function brin_minmax_multi_opcinfo(internal) is 'BRIN multi minmax support';

