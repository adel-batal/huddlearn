create function bit_in(cstring, oid, integer) returns bit
    language internal
as
$$ bit_in $$;

comment on function bit_in(cstring, oid, int4) is 'I/O';

